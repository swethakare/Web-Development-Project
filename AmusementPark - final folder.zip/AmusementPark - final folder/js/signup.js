const form = document.getElementById("signup-form");
form.addEventListener("submit", function(event) {
  event.preventDefault();
  const data = new FormData(form);
  const jsonData = {};
  data.forEach(function(value, key) {
    jsonData[key] = value;
  });
  console.log(jsonData);
});