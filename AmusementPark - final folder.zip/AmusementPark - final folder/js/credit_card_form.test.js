const { validation } = require('./credit_card_form');

describe('Credit card validation', () => {
  beforeEach(() => {
    jest.spyOn(window, 'alert').mockImplementation(() => {});
  });

  afterEach(() => {
    window.alert.mockRestore();
  });

  it('should display an alert message if the card number is empty', () => {
    document.body.innerHTML = `
      <input type="text" id="acc" value="">
      <input type="text" id="mon" value="">
      <input type="text" id="year" value="">
      <input type="text" id="cvv" value="">
    `;
    validation();
    expect(window.alert).toHaveBeenCalledWith('Card number cannot be empty');
  });

  it('should display an alert message if the card number has less than 16 digits', () => {
    document.body.innerHTML = `
      <input type="text" id="acc" value="123456789012345">
      <input type="text" id="mon" value="">
      <input type="text" id="year" value="">
      <input type="text" id="cvv" value="">
    `;
    validation();
    expect(window.alert).toHaveBeenCalledWith('card number cannot be less than 16');
  });

  it('should display an alert message if the CVV is empty', () => {
    document.body.innerHTML = `
      <input type="text" id="acc" value="1234567890123456">
      <input type="text" id="mon" value="">
      <input type="text" id="year" value="">
      <input type="text" id="cvv" value="">
    `;
    validation();
    expect(window.alert).toHaveBeenCalledWith('CVV cannot be empty');
  });

  it('should not display an alert message if all the fields are valid', () => {
    document.body.innerHTML = `
      <input type="text" id="acc" value="1234567890123456">
      <input type="text" id="mon" value="12">
      <input type="text" id="year" value="2023">
      <input type="text" id="cvv" value="123">
    `;
    validation();
    expect(window.alert).not.toHaveBeenCalled();
  });
});
