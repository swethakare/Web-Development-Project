var DB = {};
function processLogin() {
    userData = DB[$('#UserN').val()];
    console.log(userData);
    userData = DB[$('#UserN').val()];
    if (!userData) {
        $('#userid').modal('show');
        return;
    }
    if (userData["password"] !== $('#Password').val()) {
        $('#pass').modal('show');
        return;
    }
    //alert("Hi Welcome " + userData["name"]);
    document.getElementById("display").innerHTML = "Hi "+userData["name"];
    $('#bookingtick').modal('show');
}
function ticketview() {
    window.location.href = "ticketview.html";
}
$(document).ready(function () {
    $("#submitLogin").click(function () {
        processLogin();
    });
    // "C:\Users\sweth\OneDrive\Desktop\632project\nodejs\ProjectTest\JavaScript\Checkpoint-2\booking.json"
    $.getJSON("http://localhost:8080/ProjectTest/Project-2/json/logins.json", function (data) {
        DB = data;
        console.log(data)
    });

});