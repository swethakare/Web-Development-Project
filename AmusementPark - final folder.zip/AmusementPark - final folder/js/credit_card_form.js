
function validation() {
  var cardno = document.getElementById("acc").value;
  var month = document.getElementById("mon").value;
  var year = document.getElementById("year").value;
  var cvv = document.getElementById("cvv").value;
  var leng = cardno.length;
  if (cardno =='') {
    alert("Details cannot be empty"); 
    //$('#nullcardnovalidation').modal('show');
    return;
  }
  if(leng!=16){
    alert("card number cannot be less than 16");
      //$('#carddigitvalidation').modal('show');
      return;
  }
  if (cvv == '') {
    alert("CVV cannot be empty");
     //$('#cvvvalidation').modal('show');
      return; 
  }
  window.location.href = "Ticket_Confirmation.html";
}

module.exports = 
{
  validation: validation
};


 
