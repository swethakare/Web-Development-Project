function goToLogin() {
    window.location.href = "login.html";
}
function goToIndex() {
    window.location.href = "index.html";
}
function goToPayment(){
    window.location.href = "credit_card_form.html";
}
function goToSignUp(){
    window.location.href = "signup.html";
}