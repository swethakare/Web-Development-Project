
function goToLogin() {
    window.location.href = "login.html";
}
function goToSignUp() {
    window.location.href = "signup.html";
}
function main() {
    console.log("simple");
}
function loginTest(){
    $('#logintest').modal('show');
    
}
$(document).ready(function(){ 
    $("#buttontest1").click(function () {
        loginTest();
    });
    $("#buttontest2").click(function () {
        loginTest();
    });
    $("#buttontest3").click(function () {
        loginTest();
    });
})
function goToTicketBooking(TicketType) {
    sessionStorage.setItem("buttonWW", TicketType);
    var item = sessionStorage.getItem("buttonWW");
    window.location.href = "ticketbooking.html";
}


//  document.getElementById("button").innerHTML = goToPage();