const { validation } = require('./credit_card_form');

describe('validation function', () => {
  test('should return undefined when all fields are valid', () => {
    document.body.innerHTML = `
      <input type="text" id="acc" value="1111222233334444">
      <input type="text" id="mon" value="12">
      <input type="text" id="year" value="2023">
      <input type="text" id="cvv" value="123">
    `;
    expect(validation()).toBe(undefined);
  });

  test('should return undefined when card number is empty', () => {
    document.body.innerHTML = `
      <input type="text" id="acc" value="">
      <input type="text" id="mon" value="12">
      <input type="text" id="year" value="2023">
      <input type="text" id="cvv" value="123">
    `;
    expect(validation()).toBe(undefined);
    expect(window.alert).toHaveBeenCalledWith('Card number cannot be empty');
  });

  test('should return undefined when card number is less than 16 digits', () => {
    document.body.innerHTML = `
      <input type="text" id="acc" value="111122223333">
      <input type="text" id="mon" value="12">
      <input type="text" id="year" value="2023">
      <input type="text" id="cvv" value="123">
    `;
    expect(validation()).toBe(undefined);
    expect(window.alert).toHaveBeenCalledWith('Card number cannot be less than 16');
  });

  test('should return undefined when cvv is empty', () => {
    document.body.innerHTML = `
      <input type="text" id="acc" value="1111222233334444">
      <input type="text" id="mon" value="12">
      <input type="text" id="year" value="2023">
      <input type="text" id="cvv" value="">
    `;
    expect(validation()).toBe(undefined);
    expect(window.alert).toHaveBeenCalledWith('CVV cannot be empty');
  });
});
